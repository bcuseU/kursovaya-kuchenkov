import { useState, useEffect } from 'react'
import { getUsers, getGroups, createUser, updateUser, deleteUser } from '../api'
import Modal from '../components/Modal'
import Confirm from '../components/Confirm'
import { IconPlus, IconSearch, IconEdit, IconTrash } from '../components/Icons'

const ROLES = { ROLE_ADMIN: 'Администратор', ROLE_CURATOR: 'Куратор' }
const emptyForm = { username: '', password: '', fullName: '', email: '', role: 'ROLE_CURATOR', groupId: '' }

export default function UsersPage() {
  const [users, setUsers] = useState([])
  const [groups, setGroups] = useState([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')
  const [modal, setModal] = useState(false)
  const [editing, setEditing] = useState(null)
  const [form, setForm] = useState(emptyForm)
  const [saving, setSaving] = useState(false)
  const [deleting, setDeleting] = useState(null)
  const [error, setError] = useState('')

  const load = () => {
    setLoading(true)
    Promise.all([getUsers(), getGroups()])
      .then(([ur, gr]) => { setUsers(ur.data); setGroups(gr.data) })
      .finally(() => setLoading(false))
  }
  useEffect(() => { load() }, [])

  const filtered = users.filter(u =>
    !search || u.fullName?.toLowerCase().includes(search.toLowerCase()) || u.username?.toLowerCase().includes(search.toLowerCase())
  )

  const openAdd = () => {
    setForm(emptyForm); setEditing(null); setError(''); setModal(true)
  }
  const openEdit = (u) => {
    setForm({ username: u.username, password: '', fullName: u.fullName || '', email: u.email || '', role: u.role || 'ROLE_CURATOR', groupId: u.groupId ? String(u.groupId) : '' })
    setEditing(u); setError(''); setModal(true)
  }

  const handleSave = async () => {
    setSaving(true); setError('')
    try {
      const dto = { ...form, groupId: form.groupId ? Number(form.groupId) : null }
      if (!dto.password) delete dto.password
      if (editing) await updateUser(editing.id, dto)
      else await createUser(dto)
      setModal(false); load()
    } catch (e) {
      setError(e.response?.data || 'Ошибка сохранения')
    } finally { setSaving(false) }
  }

  const handleDelete = async () => {
    setSaving(true)
    try { await deleteUser(deleting.id); setDeleting(null); load() }
    catch (e) { alert(e.response?.data || 'Ошибка удаления') }
    finally { setSaving(false) }
  }

  return (
    <div className="fade-in">
      <div className="page-header">
        <div>
          <div className="page-title">Пользователи</div>
          <div className="page-subtitle">Управление кураторами и администраторами</div>
        </div>
        <button className="btn btn-primary" onClick={openAdd}>
          <IconPlus /> Добавить пользователя
        </button>
      </div>

      <div className="page-body">
        <div className="toolbar">
          <div className="search-wrap">
            <IconSearch size={15} />
            <input className="search-input" placeholder="Поиск по ФИО или логину..."
              value={search} onChange={e => setSearch(e.target.value)} />
          </div>
        </div>

        <div className="card" style={{ padding: 0 }}>
          {loading ? (
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 48, gap: 12, color: 'var(--text-muted)' }}>
              <div className="spinner" /> Загрузка...
            </div>
          ) : filtered.length === 0 ? (
            <div className="empty-state"><h3>Пользователей нет</h3></div>
          ) : (
            <div className="table-wrap">
              <table>
                <thead>
                  <tr>
                    <th>ФИО</th>
                    <th>Логин</th>
                    <th>Email</th>
                    <th>Роль</th>
                    <th>Группа</th>
                    <th></th>
                  </tr>
                </thead>
                <tbody>
                  {filtered.map(u => (
                    <tr key={u.id}>
                      <td style={{ fontWeight: 500 }}>{u.fullName}</td>
                      <td style={{ color: 'var(--text-muted)', fontFamily: 'monospace', fontSize: '0.82rem' }}>{u.username}</td>
                      <td style={{ color: 'var(--text-muted)', fontSize: '0.8rem' }}>{u.email || '—'}</td>
                      <td>
                        <span className={`badge ${u.role === 'ROLE_ADMIN' ? 'badge-yellow' : 'badge-blue'}`}>
                          {ROLES[u.role] || u.role}
                        </span>
                      </td>
                      <td style={{ color: 'var(--text-muted)', fontSize: '0.8rem' }}>
                        {u.groupNumber ? <span className="tag">{u.groupNumber}</span> : '—'}
                      </td>
                      <td>
                        <div style={{ display: 'flex', gap: 6, justifyContent: 'flex-end' }}>
                          <button className="btn-icon btn" onClick={() => openEdit(u)}><IconEdit size={13} /></button>
                          <button className="btn-icon btn" style={{ color: 'var(--red)' }} onClick={() => setDeleting(u)}><IconTrash size={13} /></button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>

      {modal && (
        <Modal
          title={editing ? 'Редактировать пользователя' : 'Новый пользователь'}
          onClose={() => setModal(false)}
          footer={
            <>
              <button className="btn btn-ghost" onClick={() => setModal(false)}>Отмена</button>
              <button className="btn btn-primary" onClick={handleSave} disabled={saving}>
                {saving ? 'Сохранение...' : 'Сохранить'}
              </button>
            </>
          }
        >
          {error && <div className="alert alert-error">{error}</div>}
          <div className="form-grid">
            <div className="form-group">
              <label className="form-label">Логин *</label>
              <input className="form-input" value={form.username} onChange={e => setForm({ ...form, username: e.target.value })} />
            </div>
            <div className="form-group">
              <label className="form-label">Пароль {editing ? '(оставьте пустым)' : '*'}</label>
              <input className="form-input" type="password" value={form.password} onChange={e => setForm({ ...form, password: e.target.value })} />
            </div>
            <div className="form-group form-full">
              <label className="form-label">ФИО *</label>
              <input className="form-input" value={form.fullName} onChange={e => setForm({ ...form, fullName: e.target.value })} />
            </div>
            <div className="form-group">
              <label className="form-label">Email</label>
              <input className="form-input" type="email" value={form.email} onChange={e => setForm({ ...form, email: e.target.value })} />
            </div>
            <div className="form-group">
              <label className="form-label">Роль</label>
              <select className="form-select" value={form.role} onChange={e => setForm({ ...form, role: e.target.value })}>
                <option value="ROLE_CURATOR">Куратор</option>
                <option value="ROLE_ADMIN">Администратор</option>
              </select>
            </div>
            {form.role === 'ROLE_CURATOR' && (
              <div className="form-group form-full">
                <label className="form-label">Группа</label>
                <select className="form-select" value={form.groupId} onChange={e => setForm({ ...form, groupId: e.target.value })}>
                  <option value="">— не назначена —</option>
                  {groups.map(g => <option key={g.id} value={g.id}>{g.groupNumber} ({g.faculty})</option>)}
                </select>
              </div>
            )}
          </div>
        </Modal>
      )}

      {deleting && (
        <Confirm
          message={`Удалить пользователя «${deleting.fullName}»?`}
          onConfirm={handleDelete}
          onCancel={() => setDeleting(null)}
          loading={saving}
        />
      )}
    </div>
  )
}
