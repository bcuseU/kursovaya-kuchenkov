import { useState, useEffect } from 'react'
import dayjs from 'dayjs'
import { getStudents, getAttendance, upsertAttendance, deleteAttendance } from '../api'

const STATUS_CYCLE = { '': 'PRESENT', 'PRESENT': 'ABSENT', 'ABSENT': 'EXCUSE', 'EXCUSE': '' }
const STATUS_LABEL = { PRESENT: 'П', ABSENT: 'Н', EXCUSE: 'У' }
const STATUS_CLASS = { PRESENT: 'att-present', ABSENT: 'att-absent', EXCUSE: 'att-excuse' }
const STATUS_NAME = { PRESENT: 'Присутствует', ABSENT: 'Отсутствует', EXCUSE: 'Уважит. причина' }

export default function AttendancePage() {
  const now = dayjs()
  const [month, setMonth] = useState(now.format('YYYY-MM'))
  const [students, setStudents] = useState([])
  const [records, setRecords] = useState([])
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState({})
  const [tooltip, setTooltip] = useState(null)

  const load = () => {
    setLoading(true)
    Promise.all([getStudents(), getAttendance(month)])
      .then(([sr, ar]) => {
        setStudents(sr.data.filter(s => s.status === 'ACTIVE'))
        setRecords(ar.data)
      })
      .finally(() => setLoading(false))
  }

  useEffect(() => { load() }, [month])

  const daysInMonth = dayjs(month).daysInMonth()
  const days = Array.from({ length: daysInMonth }, (_, i) => i + 1)

  // { "studentId_date": status }
  const recMap = {}
  records.forEach(r => {
    const day = dayjs(r.date).date()
    recMap[`${r.studentId}_${day}`] = r.status
  })

  const handleCell = async (student, day) => {
    const date = `${month}-${String(day).padStart(2, '0')}`
    const key = `${student.id}_${day}`
    const current = recMap[key] || ''
    const next = STATUS_CYCLE[current]

    setSaving(s => ({ ...s, [key]: true }))
    try {
      if (next === '') {
        await deleteAttendance(student.id, date)
        setRecords(prev => prev.filter(r => !(r.studentId === student.id && r.date === date)))
      } else {
        await upsertAttendance({ studentId: student.id, date, status: next })
        setRecords(prev => {
          const without = prev.filter(r => !(r.studentId === student.id && r.date === date))
          return [...without, { studentId: student.id, date, status: next }]
        })
      }
    } catch {}
    finally { setSaving(s => ({ ...s, [key]: false })) }
  }

  // Group by group
  const groupMap = {}
  students.forEach(s => {
    const k = s.groupNumber || 'Без группы'
    if (!groupMap[k]) groupMap[k] = []
    groupMap[k].push(s)
  })

  const today = now.date()
  const isCurrentMonth = month === now.format('YYYY-MM')

  const prevMonth = () => setMonth(dayjs(month).subtract(1, 'month').format('YYYY-MM'))
  const nextMonth = () => setMonth(dayjs(month).add(1, 'month').format('YYYY-MM'))

  return (
    <div className="fade-in">
      <div className="page-header">
        <div>
          <div className="page-title">Посещаемость</div>
          <div className="page-subtitle">
            <span className="badge badge-green" style={{ marginRight: 6 }}>П — Присутствует</span>
            <span className="badge badge-red" style={{ marginRight: 6 }}>Н — Отсутствует</span>
            <span className="badge badge-yellow">У — Уважит. причина</span>
          </div>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <button className="btn btn-ghost btn-sm" onClick={prevMonth}>←</button>
          <div style={{ fontFamily: 'var(--font-display)', fontWeight: 700, minWidth: 130, textAlign: 'center', fontSize: '0.95rem' }}>
            {dayjs(month).format('MMMM YYYY').replace(/^./, c => c.toUpperCase())}
          </div>
          <button className="btn btn-ghost btn-sm" onClick={nextMonth} disabled={isCurrentMonth && dayjs(month).month() >= now.month()}>→</button>
          <input type="month" className="form-input" style={{ padding: '6px 10px', fontSize: '0.82rem', width: 'auto' }}
            value={month} onChange={e => setMonth(e.target.value)} />
        </div>
      </div>

      <div className="page-body">
        {loading ? (
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 60, gap: 12, color: 'var(--text-muted)' }}>
            <div className="spinner" /> Загрузка...
          </div>
        ) : students.length === 0 ? (
          <div className="empty-state"><h3>Нет студентов</h3></div>
        ) : (
          Object.entries(groupMap).map(([groupName, groupStudents]) => (
            <div key={groupName} style={{ marginBottom: 32 }}>
              <div className="section-header">
                <div className="section-title">Группа {groupName}</div>
              </div>
              <div className="card" style={{ padding: 0, overflowX: 'auto' }}>
                <table style={{ minWidth: 'max-content', width: '100%', borderCollapse: 'collapse' }}>
                  <thead>
                    <tr>
                      <th style={{ position: 'sticky', left: 0, background: 'var(--bg-card)', zIndex: 2, minWidth: 200, textAlign: 'left', padding: '10px 14px' }}>
                        Студент
                      </th>
                      {days.map(d => (
                        <th key={d} style={{
                          padding: '10px 4px',
                          textAlign: 'center',
                          minWidth: 34,
                          fontSize: '0.65rem',
                          color: isCurrentMonth && d === today ? 'var(--accent)' : 'var(--text-dim)',
                          fontWeight: isCurrentMonth && d === today ? 700 : 600,
                        }}>
                          {d}
                        </th>
                      ))}
                      <th style={{ padding: '10px 14px', minWidth: 80, fontSize: '0.65rem', color: 'var(--text-dim)' }}>% явки</th>
                    </tr>
                  </thead>
                  <tbody>
                    {groupStudents.map(student => {
                      const attCount = days.filter(d => recMap[`${student.id}_${d}`] === 'PRESENT').length
                      const markedDays = days.filter(d => recMap[`${student.id}_${d}`]).length
                      const pct = markedDays > 0 ? Math.round((attCount / markedDays) * 100) : null
                      return (
                        <tr key={student.id}>
                          <td style={{ position: 'sticky', left: 0, background: 'var(--bg-card)', zIndex: 1, padding: '8px 14px', fontSize: '0.82rem', fontWeight: 500, borderBottom: '1px solid var(--border)' }}>
                            {student.lastName} {student.firstName[0]}.{student.patronymic ? ` ${student.patronymic[0]}.` : ''}
                          </td>
                          {days.map(d => {
                            const key = `${student.id}_${d}`
                            const status = recMap[key]
                            const isLoading = saving[key]
                            const isToday = isCurrentMonth && d === today
                            return (
                              <td key={d} style={{ padding: '8px 3px', textAlign: 'center', borderBottom: '1px solid var(--border)', background: isToday ? 'rgba(79,138,255,0.04)' : undefined }}>
                                <button
                                  className={`att-cell ${status ? STATUS_CLASS[status] : 'att-empty'}`}
                                  onClick={() => handleCell(student, d)}
                                  disabled={isLoading}
                                  title={status ? STATUS_NAME[status] : 'Нажмите для отметки'}
                                  style={{ opacity: isLoading ? 0.4 : 1 }}
                                >
                                  {status ? STATUS_LABEL[status] : ''}
                                </button>
                              </td>
                            )
                          })}
                          <td style={{ padding: '8px 14px', textAlign: 'center', borderBottom: '1px solid var(--border)', fontSize: '0.8rem', fontWeight: 700 }}>
                            {pct !== null ? (
                              <span style={{ color: pct >= 75 ? 'var(--green)' : 'var(--red)' }}>{pct}%</span>
                            ) : <span style={{ color: 'var(--text-dim)' }}>—</span>}
                          </td>
                        </tr>
                      )
                    })}
                  </tbody>
                </table>
              </div>
              <div style={{ marginTop: 8, fontSize: '0.75rem', color: 'var(--text-dim)' }}>
                Нажмите на ячейку для циклической смены: пусто → П → Н → У → пусто
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  )
}
