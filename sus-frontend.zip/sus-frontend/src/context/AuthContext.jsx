import { createContext, useContext, useState, useEffect } from 'react'
import { authMe } from '../api'

const AuthContext = createContext(null)

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const token = localStorage.getItem('sus_token')
    if (token) {
      authMe()
        .then(r => setUser(r.data))
        .catch(() => {
          localStorage.removeItem('sus_token')
        })
        .finally(() => setLoading(false))
    } else {
      setLoading(false)
    }
  }, [])

  const login = (userData, token) => {
    localStorage.setItem('sus_token', token)
    setUser(userData)
  }

  const logout = () => {
    localStorage.removeItem('sus_token')
    setUser(null)
  }

  const isAdmin = () => user?.roles?.includes('ROLE_ADMIN')
  const isCurator = () => user?.roles?.includes('ROLE_CURATOR') || user?.roles?.includes('ROLE_ADMIN')

  return (
    <AuthContext.Provider value={{ user, loading, login, logout, isAdmin, isCurator }}>
      {children}
    </AuthContext.Provider>
  )
}

export const useAuth = () => useContext(AuthContext)
